<?php
return [
    'db' => [
        'host'     => 'localhost',
        'dbname'   => 'elden_ring_game',
        'user'     => 'root',
        'password' => 'root',
        'charset'  => 'utf8'
    ]
];
